<?php

namespace ContainerXnYpnIQ;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder44954 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerd9f30 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties0cf59 = [
        
    ];

    public function getConnection()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getConnection', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getMetadataFactory', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getExpressionBuilder', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'beginTransaction', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getCache', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getCache();
    }

    public function transactional($func)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'transactional', array('func' => $func), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'wrapInTransaction', array('func' => $func), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'commit', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->commit();
    }

    public function rollback()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'rollback', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getClassMetadata', array('className' => $className), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'createQuery', array('dql' => $dql), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'createNamedQuery', array('name' => $name), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'createQueryBuilder', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'flush', array('entity' => $entity), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'clear', array('entityName' => $entityName), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->clear($entityName);
    }

    public function close()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'close', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->close();
    }

    public function persist($entity)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'persist', array('entity' => $entity), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'remove', array('entity' => $entity), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'refresh', array('entity' => $entity), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'detach', array('entity' => $entity), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'merge', array('entity' => $entity), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getRepository', array('entityName' => $entityName), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'contains', array('entity' => $entity), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getEventManager', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getConfiguration', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'isOpen', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getUnitOfWork', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getProxyFactory', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'initializeObject', array('obj' => $obj), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'getFilters', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'isFiltersStateClean', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'hasFilters', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return $this->valueHolder44954->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerd9f30 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder44954) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder44954 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder44954->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, '__get', ['name' => $name], $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        if (isset(self::$publicProperties0cf59[$name])) {
            return $this->valueHolder44954->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder44954;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder44954;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder44954;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder44954;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, '__isset', array('name' => $name), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder44954;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder44954;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, '__unset', array('name' => $name), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder44954;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder44954;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, '__clone', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        $this->valueHolder44954 = clone $this->valueHolder44954;
    }

    public function __sleep()
    {
        $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, '__sleep', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;

        return array('valueHolder44954');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerd9f30 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerd9f30;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerd9f30 && ($this->initializerd9f30->__invoke($valueHolder44954, $this, 'initializeProxy', array(), $this->initializerd9f30) || 1) && $this->valueHolder44954 = $valueHolder44954;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder44954;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder44954;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
